<?php
/**
 * Plugin Name: LongWEB - LearnPress Enhancer
 * Description: Thêm Notification Bar, Shortcode thống kê khóa học và tùy biến CSS dành riêng cho nền tảng học tập LongWEB.
 * Version: 1.0
 * Author: Nguyễn Hải Long
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Chống truy cập trực tiếp
}

// =========================================================================
// YÊU CẦU 1: HIỂN THỊ THÔNG BÁO "HỌC VIÊN MỚI" (NOTIFICATION BAR)
// =========================================================================
add_action('wp_footer', 'longweb_notification_bar');
function longweb_notification_bar() {
    // Chỉ hiển thị trên trang chi tiết khóa học của LearnPress
    if ( ! is_singular( 'lp_course' ) ) {
        return;
    }

    $message = '';
    if ( is_user_logged_in() ) {
        $current_user = wp_get_current_user();
        $message = "Chào <strong>" . esc_html( $current_user->display_name ) . "</strong>, mừng bạn đến với <strong>LongWEB</strong>. Bạn đã sẵn sàng bắt đầu bài học hôm nay chưa?";
    } else {
        $message = "<strong>Đăng nhập</strong> để lưu tiến độ học tập trên LongWEB!";
    }

    // In ra HTML của thanh thông báo
    echo '<div id="longweb-notification-bar">' . $message . '</div>';
}

// =========================================================================
// YÊU CẦU 2: SHORTCODE THỐNG KÊ CHI TIẾT KHÓA HỌC
// =========================================================================
add_shortcode('lp_course_info', 'longweb_course_info_shortcode');
function longweb_course_info_shortcode( $atts ) {
    $atts = shortcode_atts( array(
        'id' => get_the_ID(),
    ), $atts );

    $course_id = intval( $atts['id'] );

    if ( ! class_exists( 'LP_Course' ) || get_post_type( $course_id ) !== 'lp_course' ) {
        return '<p style="color:red;">Không tìm thấy khóa học hợp lệ trên hệ thống LongWEB.</p>';
    }

    $course = learn_press_get_course( $course_id );
    if ( ! $course ) return '';

    // 1. Số lượng bài học
    $lesson_count = $course->count_items( 'lp_lesson' );

    // 2. Thời lượng dự kiến
    $duration = get_post_meta( $course_id, '_lp_duration', true );
    if ( empty( $duration ) ) $duration = 'Không giới hạn';

    // 3. Trạng thái người dùng
    $status_text = '<span style="color: #888;">Chưa đăng ký</span>';
    if ( is_user_logged_in() ) {
        $user = learn_press_get_current_user();
        if ( $user->has_enrolled_course( $course_id ) ) {
            $course_data = $user->get_course_data( $course_id );
            if ( $course_data && $course_data->get_status() == 'completed' ) {
                $status_text = '<span style="color: #28a745;">Đã hoàn thành</span>';
            } else {
                $status_text = '<span style="color: #ff9800;">Đã đăng ký (Đang học)</span>';
            }
        }
    }

    // Trả về HTML
    ob_start();
    ?>
    <div class="longweb-course-stats">
        <h4>📊 Thống kê khóa học LongWEB</h4>
        <ul>
            <li><strong>Số lượng bài học:</strong> <?php echo esc_html( $lesson_count ); ?></li>
            <li><strong>Thời gian dự kiến:</strong> <?php echo esc_html( $duration ); ?></li>
            <li><strong>Trạng thái của bạn:</strong> <?php echo $status_text; ?></li>
        </ul>
    </div>
    <?php
    return ob_get_clean();
}

// =========================================================================
// YÊU CẦU 3: TÙY BIẾN STYLE (CUSTOM CSS)
// =========================================================================
add_action('wp_head', 'longweb_custom_styles');
function longweb_custom_styles() {
    ?>
    <style>
        /* Notification Bar */
        #longweb-notification-bar {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background-color: #1a237e; /* Màu xanh đen sang trọng */
            color: #ffffff;
            text-align: center;
            padding: 12px 0;
            z-index: 9999;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            font-size: 16px;
        }
        
        /* body.single-lp_course {
            padding-top: 50px !important; 
        } */
            body.admin-bar #longweb-notification-bar {
            top: 32px; 
        }
        
        body.single-lp_course {
            padding-top: 50px !important; 
        }

        /* Shortcode Stats Box */
        .longweb-course-stats {
            background: #ffffff;
            border-left: 5px solid #1a237e;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            padding: 20px;
            margin: 25px 0;
            border-radius: 8px;
        }
        .longweb-course-stats ul { list-style: none; padding-left: 0; margin-bottom: 0; }
        .longweb-course-stats li { margin-bottom: 10px; font-size: 15px; }

        /* Tùy biến màu nút Enroll và Finish Course sang màu của LongWEB */
        .lp-button.button.button-enroll-course,
        .lp-button.button.button-finish-course,
        form.enroll-course button[type="submit"],
        form.lp-form-finish-course button[type="submit"] {
            background-color: #1a237e !important; /* Xanh chủ đạo */
            border-color: #121858 !important;
            color: #fff !important;
            border-radius: 6px !important;
            font-weight: bold !important;
            transition: all 0.3s ease !important;
        }

        .lp-button.button.button-enroll-course:hover,
        .lp-button.button.button-finish-course:hover,
        form.enroll-course button[type="submit"]:hover,
        form.lp-form-finish-course button[type="submit"]:hover {
            background-color: #283593 !important; /* Sáng hơn khi hover */
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }
    </style>
    <?php
}